export class ISkill {
    skillName: string;
    experienceInYears: number;
    proficiency: string;
}